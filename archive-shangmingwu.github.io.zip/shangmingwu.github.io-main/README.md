# My site

Hello! This is the repository that hosts the files to build my personal website. (If you haven't seen that yet, you can click [here](https://simonwu.dev).)

Currently, it's a static site built with Hugo and hosted on GitHub. An Action builds the static files and pushes the artifacts to GitHub Pages for hosting.
