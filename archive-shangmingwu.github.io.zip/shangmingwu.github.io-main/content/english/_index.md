+++
author = "Simon Wu"
+++

# Hi, I'm Simon!

I'm studying Computer Science at the University of Waterloo, and I like to [make stuff](/portfolio), read [interesting books](https://www.libib.com/u/simonwu/), and attempt difficult things.

I'm currently searching for internship opportunities for Summer 2023. If you're interested in hiring me, you can see my [portfolio](/portfolio) and [resume](/resume), and contact me by [email](mailto:simon.wu1@uwaterloo.ca) or on [LinkedIn](www.linkedin.com/in/simon-wu-53636a243).

You can find my writing on my [blog](https://simonwu.substack.com), which I've recently migrated to Substack.
